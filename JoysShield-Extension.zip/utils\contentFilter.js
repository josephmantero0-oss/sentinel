class ContentFilter {
    // 1. Explicit Adult & Vulgar Keywords (English + Multilingual Transliterated)
    static VULGAR_KEYWORDS = [
        // English Adult & Explicit
        'porn', 'porno', 'xxx', 'adult', 'nsfw', 'erotic', 'hentai', 'nude', 'naked',
        'xvideo', 'xvideos', 'pornhub', 'redtube', 'youporn', 'xhamster', 'onlyfans',
        'camgirl', 'stripchat', 'chaturbate', 'brazzers', 'bangbros', 'spankbang', 'rule34',
        
        // Portuguese Transliterated & Explicit
        'putaria', 'transar', 'bunda', 'caralho', 'buceta', 'gozar', 'prostituta',
        'safada', 'pelada', 'punheta', 'trepar', 'comendo', 'pica',
        
        // Spanish / Italian Transliterated
        'puta', 'puto', 'sexo', 'desnuda', 'desnudo', 'folla', 'chingar', 'scopare', 'figa',
        
        // French / German Transliterated
        'salope', 'baiser', 'bite', 'chatte', 'ficken', 'fotze', 'schwanz', 'nackt',

        // Southeast Asian (Filipino / Indonesian) Transliterated
        'bastos', 'kantot', 'pekpek', 'bokep', 'ngewe', 'bugil'
    ];

    // 2. Casino, Gambling, Betting & Card Games Keywords
    static CASINO_KEYWORDS = [
        'casino', 'gambling', 'betting', 'gamble', 'bet365', '1xbet', 'stake.com',
        'slots', 'slot machine', 'poker', 'roulette', 'blackjack', 'baccarat',
        'craps', 'jackpot', 'aviator game', 'teen patti', 'andar bahar',
        'satta matka', 'matka', 'dream11', 'winzo', 'bookmaker', 'lottery', 'spin the wheel'
    ];

    /**
     * Analyzes a URL object for explicit adult or gambling/casino content.
     * @param {URL} urlObj 
     * @returns {Object} { isVulgar: boolean, reason: string|null, matched: string|null }
     */
    static analyzeUrl(urlObj) {
        const fullUrl = (urlObj.hostname + urlObj.pathname + urlObj.search).toLowerCase();

        // Check Vulgar & Adult Keywords
        for (const word of this.VULGAR_KEYWORDS) {
            if (fullUrl.includes(word)) {
                return { isVulgar: true, reason: 'vulgar_link', matched: word };
            }
        }

        // Check Casino & Gambling Keywords
        for (const word of this.CASINO_KEYWORDS) {
            if (fullUrl.includes(word)) {
                return { isVulgar: true, reason: 'casino_gambling', matched: word };
            }
        }

        return { isVulgar: false, reason: null, matched: null };
    }
}

export default ContentFilter;
