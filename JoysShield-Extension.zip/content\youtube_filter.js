(function () {
    'use strict';

    /**
     * AI SECURITY SHIELD ENGINE FOR YOUTUBE
     * Multi-layered Content & Threat Analysis
     */

    // 1. Adult & Vulgar Keywords Matrix (English, Portuguese, Spanish, French, German, Tagalog, Indonesian)
    const ADULT_KEYWORDS = [
        // English Adult & Explicit
        'porn', 'porno', 'xxx', 'adult', 'nsfw', 'erotic', 'hentai', 'nude', 'naked',
        'xvideo', 'xvideos', 'pornhub', 'redtube', 'youporn', 'xhamster', 'onlyfans',
        'camgirl', 'stripchat', 'chaturbate', 'brazzers', 'bangbros', 'spankbang', 'rule34', 'sex', 'sexy', 'Violence', 'Violent',

        // Portuguese Transliterated & Explicit
        'putaria', 'transar', 'bunda', 'caralho', 'buceta', 'gozar', 'prostituta',
        'safada', 'pelada', 'punheta', 'trepar', 'comendo', 'pica',

        // Spanish / Italian Transliterated
        'puta', 'puto', 'sexo', 'desnuda', 'desnudo', 'folla', 'chingar', 'scopare', 'figa',

        // French / German Transliterated
        'salope', 'baiser', 'bite', 'chatte', 'ficken', 'fotze', 'schwanz', 'nackt',

        // Southeast Asian (Filipino / Indonesian) Transliterated
        'bastos', 'kantot', 'pekpek', 'bokep', 'ngewe', 'bugil'
    ];

    // 2. Casino, Gambling, Betting & Card Games Matrix
    const CASINO_KEYWORDS = [
        'casino', 'gambling', 'betting', 'gamble', 'bet365', '1xbet', 'stake.com',
        'slots', 'slot machine', 'poker', 'roulette', 'blackjack', 'baccarat',
        'craps', 'jackpot', 'aviator game', 'teen patti', 'andar bahar',
        'satta matka', 'matka', 'dream11', 'winzo', 'bookmaker', 'flush', 'straight', 'royal flush', 'lottery'
    ];

    // Build strict regex dictionary
    const ADULT_REGEXES = ADULT_KEYWORDS.map(kw => ({
        keyword: kw,
        regex: new RegExp('\\b' + kw.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&') + '\\b', 'i')
    }));

    const CASINO_REGEXES = CASINO_KEYWORDS.map(kw => ({
        keyword: kw,
        regex: new RegExp('\\b' + kw.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&') + '\\b', 'i')
    }));

    let currentVideoId = null;
    let observer = null;

    /**
     * Gets current YouTube Video ID or Short ID from URL
     */
    function getCurrentMediaId() {
        const path = window.location.pathname;
        if (path.includes('/watch')) {
            return new URLSearchParams(window.location.search).get('v') || path;
        } else if (path.includes('/shorts/')) {
            const parts = path.split('/shorts/');
            return parts[1] ? parts[1].split('/')[0] : path;
        }
        return null;
    }

    /**
     * Unblocks the player and cleans up existing block overlays
     */
    function unblockPlayer() {
        const overlay = document.getElementById('joseph-shield-overlay');
        if (overlay) {
            overlay.remove();
        }

        document.querySelectorAll('[data-joseph-blocked]').forEach(el => {
            el.removeAttribute('data-joseph-blocked');
        });

        // Ensure video is unmuted if previously paused by shield
        const videos = document.querySelectorAll('video');
        videos.forEach(v => {
            if (v.hasAttribute('data-joseph-paused')) {
                v.removeAttribute('data-joseph-paused');
            }
        });
    }

    /**
     * AI Risk Evaluator: Analyzes extracted text metadata against risk weights
     */
    function evaluateAIRisk(textData) {
        if (!textData) return { isBlocked: false, category: null, matchedKeyword: null };

        const lowerText = textData.toLowerCase();

        // 1. Check Adult Category
        for (const item of ADULT_REGEXES) {
            if (item.regex.test(lowerText)) {
                return { isBlocked: true, category: 'adult', matchedKeyword: item.keyword };
            }
        }

        // 2. Check Casino & Gambling Category
        for (const item of CASINO_REGEXES) {
            if (item.regex.test(lowerText)) {
                return { isBlocked: true, category: 'casino', matchedKeyword: item.keyword };
            }
        }

        return { isBlocked: false, category: null, matchedKeyword: null };
    }

    /**
     * Renders a premium glassmorphic security overlay without destroying YouTube's player DOM
     */
    function mountSecurityOverlay(container, riskData) {
        if (!container) return;

        const mediaId = getCurrentMediaId() || 'active';
        if (container.getAttribute('data-joseph-blocked') === mediaId) {
            // Already blocked for this video
            const video = container.querySelector('video') || document.querySelector('video');
            if (video && !video.paused) {
                video.pause();
            }
            return;
        }

        container.setAttribute('data-joseph-blocked', mediaId);

        // Ensure relative positioning
        if (getComputedStyle(container).position === 'static') {
            container.style.position = 'relative';
        }

        let overlay = document.getElementById('joseph-shield-overlay');
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = 'joseph-shield-overlay';
            overlay.style.cssText = `
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: linear-gradient(135deg, rgba(15, 23, 42, 0.98), rgba(11, 15, 25, 0.99));
                backdrop-filter: blur(12px);
                color: #f87171;
                z-index: 999999;
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
                padding: 30px;
                box-sizing: border-box;
                text-align: center;
                font-family: 'Inter', system-ui, -apple-system, sans-serif;
                border: 2px solid #ef4444;
                border-radius: 12px;
                box-shadow: 0 20px 50px rgba(0,0,0,0.8);
            `;
            container.appendChild(overlay);
        }

        const isCasino = riskData.category === 'casino';
        const icon = isCasino ? '🎰' : '🔞';
        const titleText = isCasino ? 'Casino / Gambling Content Shield' : 'Inappropriate Content Shield';

        overlay.innerHTML = `
            <div style="font-size: 56px; margin-bottom: 12px; filter: drop-shadow(0 4px 10px rgba(239, 68, 68, 0.4));">${icon}</div>
            <h2 style="font-size: 26px; font-weight: 700; margin-bottom: 12px; color: #fca5a5; letter-spacing: -0.5px;">${titleText}</h2>
            <p style="color: #cbd5e1; font-size: 15px; max-width: 540px; line-height: 1.6; margin: 0 0 20px 0;">
                This YouTube content has been blocked by <strong>Joseph's Sentinel</strong> (Detected keyword: <span style="background: rgba(239, 68, 68, 0.2); color: #f87171; padding: 2px 8px; border-radius: 6px; font-weight: 600;">"${riskData.matchedKeyword}"</span>).
            </p>
            <div style="display: flex; gap: 12px;">
                <button id="joseph-btn-back" style="background: #ef4444; color: #ffffff; border: none; padding: 12px 24px; border-radius: 8px; font-weight: 600; cursor: pointer; font-size: 14px; transition: all 0.2s ease;">Back to Safety</button>
            </div>
        `;

        document.getElementById('joseph-btn-back').addEventListener('click', () => {
            window.history.back();
        });

        // Pause video stream
        const videos = document.querySelectorAll('video');
        videos.forEach(v => {
            v.setAttribute('data-joseph-paused', 'true');
            v.pause();
        });
    }

    /**
     * Primary YouTube Scanner: Extracts metadata from DOM, Document Title, and Thumbnails
     */
    function scanAndFilterYouTube() {
        const mediaId = getCurrentMediaId();

        // If URL changed to a different video/page, unblock overlay
        if (mediaId !== currentVideoId) {
            currentVideoId = mediaId;
            unblockPlayer();
        }

        if (!mediaId) {
            unblockPlayer();
            return;
        }

        // 1. Gather Page Metadata
        const docTitle = document.title || '';

        // Main Video Title & Metadata selectors
        const titleElem = document.querySelector(
            'h1.ytd-watch-metadata, #title h1, h1.title, #metadata #title, ' +
            '.ytd-reel-player-header-renderer #title, ytd-reel-video-renderer[is-active] #title'
        );

        const descElem = document.querySelector('#description-inline-expander, #description, #snippet');
        const channelElem = document.querySelector('#channel-name, #owner-name, .ytd-channel-name');

        // Thumbnail & Visual alt text selectors
        const thumbnailImgs = document.querySelectorAll('ytd-watch-flexy img, ytd-player img');
        let thumbnailAltText = '';
        thumbnailImgs.forEach(img => {
            if (img.alt) thumbnailAltText += ' ' + img.alt;
        });

        const combinedMetadata = [
            docTitle,
            titleElem ? titleElem.textContent : '',
            descElem ? descElem.textContent : '',
            channelElem ? channelElem.textContent : '',
            thumbnailAltText
        ].join(' ');

        // 2. Evaluate with AI Risk Engine
        const riskResult = evaluateAIRisk(combinedMetadata);

        if (riskResult.isBlocked) {
            console.warn("[Joseph's Sentinel] Blocked YouTube content:", riskResult);

            // Send stat to background script
            try {
                chrome.runtime.sendMessage({
                    type: 'YOUTUBE_VIDEO_BLOCKED',
                    title: docTitle,
                    keyword: riskResult.matchedKeyword,
                    category: riskResult.category,
                    url: window.location.href
                });
            } catch (e) { /* ignore if background not ready */ }

            if (window.location.pathname.includes('/shorts')) {
                // Try multiple Shorts container selectors (YouTube changes these often)
                const activeShort =
                    document.querySelector('ytd-reel-video-renderer[is-active]') ||
                    document.querySelector('ytd-reel-video-renderer.is-active') ||
                    document.querySelector('ytd-shorts ytd-reel-video-renderer') ||
                    document.querySelector('ytd-reel-video-renderer') ||
                    document.querySelector('#shorts-player') ||
                    document.querySelector('.reel-player-overlay-renderer');

                if (activeShort) {
                    mountSecurityOverlay(activeShort, riskResult);
                } else {
                    // Fallback: overlay on the body-level shorts container
                    const shortsContainer = document.querySelector('ytd-shorts, #page-manager');
                    if (shortsContainer) mountSecurityOverlay(shortsContainer, riskResult);
                }
            } else {
                const player = document.querySelector(
                    '#movie_player, .html5-video-player, #ytd-player, #player-container'
                );
                if (player) {
                    mountSecurityOverlay(player, riskResult);
                }
            }
        }
    }

    // 1. Listen to YouTube Native SPA Events for instant <1ms unblocking & scanning
    window.addEventListener('yt-navigate-start', () => {
        unblockPlayer();
    });

    window.addEventListener('yt-page-data-updated', () => {
        scanAndFilterYouTube();
    });

    window.addEventListener('yt-navigate-finish', () => {
        scanAndFilterYouTube();
    });

    window.addEventListener('popstate', () => {
        unblockPlayer();
        scanAndFilterYouTube();
    });

    // 2. Setup MutationObserver for real-time <5ms DOM title & metadata changes
    function setupMutationObserver() {
        if (observer) return;

        const target = document.querySelector('head title') || document.body;
        if (!target) return;

        observer = new MutationObserver(() => {
            scanAndFilterYouTube();
        });

        observer.observe(document.head, { childList: true, subtree: true, characterData: true });

        const pageManager = document.querySelector('#page-manager, ytd-app');
        if (pageManager) {
            observer.observe(pageManager, { childList: true, subtree: true });
        }
    }

    // Initialize Observer & Initial Scan
    if (document.readyState === 'complete' || document.readyState === 'interactive') {
        setupMutationObserver();
        scanAndFilterYouTube();
    } else {
        document.addEventListener('DOMContentLoaded', () => {
            setupMutationObserver();
            scanAndFilterYouTube();
        });
    }

    // Backup periodic interval (600ms)
    setInterval(scanAndFilterYouTube, 600);
})();
