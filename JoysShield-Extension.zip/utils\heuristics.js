class HeuristicsAnalyzer {
    // Top-Level Domains known to be frequently abused
    static SUSPICIOUS_TLDS = ['.xyz', '.top', '.tk', '.fit', '.cc', '.click', '.gq', '.pw', '.cn'];

    // Core brand names to check for typosquatting
    static TARGET_BRANDS = ['microsoft', 'google', 'apple', 'paypal', 'facebook', 'amazon', 'netflix', 'bankofamerica', 'chase', 'wellsfargo'];

    // Suspicious keywords often used in paths or subdomains of phishing sites
    static SUSPICIOUS_KEYWORDS = ['secure-login', 'verify-account', 'paypal-signin', 'web-update', 'login', 'secure', 'account', 'verify', 'update', 'banking', 'auth'];

    /**
     * Analyzes a URL for phishing indicators.
     * @param {URL} urlObj 
     * @returns {Object} result - { isPhishing: boolean, reason: string|null }
     */
    static analyze(urlObj) {
        const hostname = urlObj.hostname;
        const pathname = urlObj.pathname.toLowerCase();

        // 1. IP Domain Check - Is the host just an IP address?
        const ipv4Regex = /^(\d{1,3}\.){3}\d{1,3}$/;
        if (ipv4Regex.test(hostname)) {
            return { isPhishing: true, reason: 'heuristics_ip' };
        }

        // 2. Subdomain Overload - Count dots in hostname (e.g., login.secure.bank.com -> 3 dots = 4 parts)
        const parts = hostname.split('.');
        // e.g., co.uk and similar complexities we'll roughly handle just by raw count for this basic heuristic
        if (parts.length > 4) { // e.g. a.b.c.d.com
            return { isPhishing: true, reason: 'heuristics_subdomain' };
        }

        // 3. Suspicious TLD Check
        const tld = "." + parts[parts.length - 1].toLowerCase();
        if (this.SUSPICIOUS_TLDS.includes(tld)) {
            // Just having a bad TLD is suspicious but maybe not blocked outright, unless combined with other signals.
            // We'll return true for a strict approach.
            return { isPhishing: true, reason: 'heuristics_TLD' };
        }

        // 4. Suspicious Keywords Check in Hostname or Path
        if (this.SUSPICIOUS_KEYWORDS.some(kw => hostname.includes(kw) || pathname.includes(kw))) {
            // If a site like paypal.com has "login", it's fine. We need to be careful with false positives.
            // But for this simple project, if we see them in unusual combos without being the main brand...
            // Let's rely on it if it's NOT the actual brand.
            const isLegitBrand = this.TARGET_BRANDS.some(brand => hostname === `${brand}.com`);
            if (!isLegitBrand) {
                return { isPhishing: true, reason: 'heuristics_keywords' };
            }
        }

        // 5. Typosquatting Check (Very basic length & replace check for simplicity)
        // Check if they replace 'o' with '0' or 'i' with '1' on popular brands.
        for (const brand of this.TARGET_BRANDS) {
            const t1 = brand.replace('o', '0');
            const t2 = brand.replace('i', '1');
            if ((t1 !== brand && hostname.includes(t1)) || (t2 !== brand && hostname.includes(t2))) {
                return { isPhishing: true, reason: 'heuristics_typo' };
            }
        }

        return { isPhishing: false, reason: null };
    }
}

export default HeuristicsAnalyzer;
