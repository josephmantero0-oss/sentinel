class WhitelistManager {
    static async isWhitelisted(hostname) {
        return new Promise((resolve) => {
            chrome.storage.local.get(['whitelist'], (result) => {
                const whitelist = result.whitelist || [];
                resolve(whitelist.includes(hostname));
            });
        });
    }

    static async addToWhitelist(hostname) {
        return new Promise((resolve) => {
            chrome.storage.local.get(['whitelist'], (result) => {
                const whitelist = result.whitelist || [];
                if (!whitelist.includes(hostname)) {
                    whitelist.push(hostname);
                    chrome.storage.local.set({ whitelist: whitelist }, resolve);
                } else {
                    resolve();
                }
            });
        });
    }

    static async removeFromWhitelist(hostname) {
        return new Promise((resolve) => {
            chrome.storage.local.get(['whitelist'], (result) => {
                let whitelist = result.whitelist || [];
                whitelist = whitelist.filter(domain => domain !== hostname);
                chrome.storage.local.set({ whitelist: whitelist }, resolve);
            });
        });
    }
}

export default WhitelistManager;
