import WhitelistManager from '../utils/whitelist.js';

document.addEventListener('DOMContentLoaded', async () => {
    // ── Elements ──────────────────────────────────────────────────
    const statusCard      = document.getElementById('status-card');
    const currentStatus   = document.getElementById('current-status');
    const currentDomainEl = document.getElementById('current-domain');
    const btnWhitelist    = document.getElementById('btn-whitelist');
    const btnClearStats   = document.getElementById('btn-clear-stats');

    // Stats
    const statSites   = document.getElementById('stat-sites-blocked');
    const statYT      = document.getElementById('stat-yt-blocked');
    const statScans   = document.getElementById('stat-scans');
    const statWL      = document.getElementById('stat-whitelisted');

    // Tables
    const sitesTbody     = document.getElementById('sites-tbody');
    const ytTbody        = document.getElementById('yt-tbody');
    const whitelistTbody = document.getElementById('whitelist-tbody');

    // Filters & Sorts
    const filterSites  = document.getElementById('filter-sites');
    const sortSites    = document.getElementById('sort-sites');
    const filterYt     = document.getElementById('filter-yt');
    const sortYt       = document.getElementById('sort-yt');
    const filterWl     = document.getElementById('filter-whitelist');

    let currentHostname = '';
    let allSiteHistory  = [];
    let allYtHistory    = [];

    // ── Tab Switching ─────────────────────────────────────────────
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
            btn.classList.add('active');
            document.getElementById(btn.dataset.tab).classList.add('active');
        });
    });

    // ── Load Current Tab ──────────────────────────────────────────
    if (chrome && chrome.tabs) {
        chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
            const tab = tabs[0];
            if (tab && tab.url) {
                try {
                    const urlObj = new URL(tab.url);
                    currentHostname = urlObj.hostname;
                    currentDomainEl.textContent = currentHostname || tab.url;

                    if (['chrome-extension:', 'chrome:', 'file:'].includes(urlObj.protocol)) {
                        currentStatus.textContent = 'Safe (Local)';
                        statusCard.className = 'card status-safe';
                        return;
                    }

                    updateSiteState(currentHostname);
                } catch (e) {
                    currentDomainEl.textContent = 'Invalid URL';
                    currentStatus.textContent = 'Unknown Status';
                }
            }
        });
    }

    async function updateSiteState(hostname) {
        const isSafe = await WhitelistManager.isWhitelisted(hostname);
        btnWhitelist.disabled = false;

        if (isSafe) {
            currentStatus.textContent = 'Site is Whitelisted ✅';
            statusCard.className = 'card status-safe';
            btnWhitelist.textContent = 'Remove from Whitelist';
            btnWhitelist.className = 'btn btn-remove';
        } else {
            currentStatus.textContent = 'Analysis Active 🔍';
            statusCard.className = 'card status-checking';
            btnWhitelist.textContent = 'Add to Whitelist';
            btnWhitelist.className = 'btn';
        }
    }

    // ── Whitelist Toggle ──────────────────────────────────────────
    btnWhitelist.addEventListener('click', async () => {
        if (!currentHostname) return;
        const isSafe = await WhitelistManager.isWhitelisted(currentHostname);
        if (isSafe) {
            await WhitelistManager.removeFromWhitelist(currentHostname);
        } else {
            await WhitelistManager.addToWhitelist(currentHostname);
        }
        updateSiteState(currentHostname);
        loadAll();
    });

    // ── Clear Stats ───────────────────────────────────────────────
    btnClearStats.addEventListener('click', () => {
        if (!confirm('Clear all statistics and history?')) return;
        chrome.storage.local.set({
            totalSitesBlocked: 0,
            totalYouTubeBlocked: 0,
            totalScans: 0,
            blockedSiteHistory: [],
            blockedYouTubeHistory: []
        }, loadAll);
    });

    // ── Load Everything ───────────────────────────────────────────
    function loadAll() {
        chrome.storage.local.get(
            ['totalSitesBlocked', 'totalYouTubeBlocked', 'totalScans',
             'blockedSiteHistory', 'blockedYouTubeHistory', 'whitelist'],
            (result) => {
                // Stats counters
                statSites.textContent = (result.totalSitesBlocked  || 0).toLocaleString();
                statYT.textContent    = (result.totalYouTubeBlocked || 0).toLocaleString();
                statScans.textContent = (result.totalScans          || 0).toLocaleString();
                statWL.textContent    = (result.whitelist            || []).length;

                allSiteHistory = result.blockedSiteHistory  || [];
                allYtHistory   = result.blockedYouTubeHistory || [];

                renderSitesTable();
                renderYtTable();
                renderWhitelistTable(result.whitelist || []);
            }
        );
    }

    // ── Sites Table ───────────────────────────────────────────────
    function renderSitesTable() {
        const query  = filterSites.value.toLowerCase();
        const sort   = sortSites.value;

        let data = allSiteHistory.filter(r =>
            (r.url || '').toLowerCase().includes(query) ||
            (r.reason || '').toLowerCase().includes(query)
        );

        data = sortData(data, sort, 'site');

        if (data.length === 0) {
            sitesTbody.innerHTML = '<tr><td colspan="3" class="empty-row">No blocked sites yet</td></tr>';
            return;
        }

        sitesTbody.innerHTML = data.map(r => {
            const host    = tryHost(r.url);
            const reason  = formatReason(r.reason);
            const timeStr = formatTime(r.time);
            return `<tr>
                <td title="${escHtml(r.url)}">${escHtml(host)}</td>
                <td>${reason}</td>
                <td title="${escHtml(r.time)}">${timeStr}</td>
            </tr>`;
        }).join('');
    }

    // ── YouTube Table ─────────────────────────────────────────────
    function renderYtTable() {
        const query = filterYt.value.toLowerCase();
        const sort  = sortYt.value;

        let data = allYtHistory.filter(r =>
            (r.title   || '').toLowerCase().includes(query) ||
            (r.keyword || '').toLowerCase().includes(query) ||
            (r.category|| '').toLowerCase().includes(query)
        );

        data = sortData(data, sort, 'yt');

        if (data.length === 0) {
            ytTbody.innerHTML = '<tr><td colspan="4" class="empty-row">No YouTube videos blocked yet</td></tr>';
            return;
        }

        ytTbody.innerHTML = data.map(r => {
            const catBadge = r.category === 'casino'
                ? '<span class="badge badge-warning">🎰 Casino</span>'
                : '<span class="badge badge-danger">🔞 Adult</span>';
            return `<tr>
                <td title="${escHtml(r.title)}">${escHtml(truncate(r.title, 28))}</td>
                <td><code style="color:#f87171;font-size:0.7rem">${escHtml(r.keyword || '')}</code></td>
                <td>${catBadge}</td>
                <td>${formatTime(r.time)}</td>
            </tr>`;
        }).join('');
    }

    // ── Whitelist Table ───────────────────────────────────────────
    function renderWhitelistTable(whitelist) {
        const query = filterWl.value.toLowerCase();
        const data  = whitelist.filter(d => d.toLowerCase().includes(query));

        if (data.length === 0) {
            whitelistTbody.innerHTML = '<tr><td colspan="2" class="empty-row">No whitelisted sites</td></tr>';
            return;
        }

        whitelistTbody.innerHTML = data.map(domain => `
            <tr>
                <td>${escHtml(domain)}</td>
                <td style="width:36px;text-align:center">
                    <button class="remove-btn" data-domain="${escHtml(domain)}" title="Remove">✕</button>
                </td>
            </tr>
        `).join('');

        whitelistTbody.querySelectorAll('.remove-btn').forEach(btn => {
            btn.addEventListener('click', async () => {
                await WhitelistManager.removeFromWhitelist(btn.dataset.domain);
                if (currentHostname === btn.dataset.domain) updateSiteState(currentHostname);
                loadAll();
            });
        });
    }

    // ── Filter & Sort listeners ───────────────────────────────────
    filterSites.addEventListener('input', renderSitesTable);
    sortSites.addEventListener('change', renderSitesTable);
    filterYt.addEventListener('input', renderYtTable);
    sortYt.addEventListener('change', renderYtTable);
    filterWl.addEventListener('input', () => {
        chrome.storage.local.get(['whitelist'], r => renderWhitelistTable(r.whitelist || []));
    });

    // ── Helpers ───────────────────────────────────────────────────
    function sortData(arr, sort, type) {
        return [...arr].sort((a, b) => {
            if (sort === 'time-desc') return new Date(b.time) - new Date(a.time);
            if (sort === 'time-asc')  return new Date(a.time) - new Date(b.time);
            if (type === 'site') {
                if (sort === 'reason') return (a.reason || '').localeCompare(b.reason || '');
                if (sort === 'url')    return (a.url    || '').localeCompare(b.url    || '');
            }
            if (type === 'yt') {
                if (sort === 'category') return (a.category || '').localeCompare(b.category || '');
                if (sort === 'keyword')  return (a.keyword  || '').localeCompare(b.keyword  || '');
            }
            return 0;
        });
    }

    function formatReason(reason) {
        const map = {
            blacklist:           '<span class="badge badge-danger">Blacklist</span>',
            insecure_connection: '<span class="badge badge-warning">HTTP</span>',
            adult_content:       '<span class="badge badge-danger">Adult</span>',
            vulgar_content:      '<span class="badge badge-danger">Vulgar</span>',
            casino:              '<span class="badge badge-warning">Casino</span>',
            phishing_heuristic:  '<span class="badge badge-info">Heuristic</span>',
        };
        return map[reason] || `<span class="badge badge-info">${escHtml(reason || 'Unknown')}</span>`;
    }

    function formatTime(iso) {
        if (!iso) return '—';
        try {
            const d = new Date(iso);
            const now = new Date();
            const diff = now - d;
            if (diff < 60000)    return 'just now';
            if (diff < 3600000)  return Math.floor(diff/60000) + 'm ago';
            if (diff < 86400000) return Math.floor(diff/3600000) + 'h ago';
            return d.toLocaleDateString('en-GB', { day:'2-digit', month:'short' });
        } catch { return iso; }
    }

    function tryHost(url) {
        try { return new URL(url).hostname; } catch { return url || '—'; }
    }

    function truncate(str, n) {
        if (!str) return '—';
        return str.length > n ? str.slice(0, n) + '…' : str;
    }

    function escHtml(str) {
        return (str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }

    // Initial load
    loadAll();
});
